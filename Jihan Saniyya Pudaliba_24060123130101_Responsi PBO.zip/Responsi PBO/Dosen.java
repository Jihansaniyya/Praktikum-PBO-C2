public class Dosen extends Karyawan implements InfoCivitas{
    private Fakultas fakultas;
    private static int counterDosen = 0;
    

    public Dosen(String nama, String email, String NIP, int masaKerja, Fakultas fakultas) {
        super(nama, email, NIP, masaKerja);
        this.fakultas = fakultas;
        counterDosen++;
    }

    public static int getCounterDosen(){
        return counterDosen;
    }

    @Override
    public double hitungGaji(){
        return fakultas.getGajiPokok() + (masakerja * 0.01 * fakultas.getGajiPokok());
    }

    @Override
    public void tampilkanInformasi(){
        System.out.println("================INFORMASI DOSEN================");
        System.out.println("NIP: " + NIP);
        System.out.println("Nama: " + nama);
        System.out.println("Email: " + email);
        System.out.println("Fakultas: " + fakultas.getNama());
        System.out.println("Masa Kerja: " + masakerja);
        System.out.println("Gaji: " + hitungGaji());
    }
}

