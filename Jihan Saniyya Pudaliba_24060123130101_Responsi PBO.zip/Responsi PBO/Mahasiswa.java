public class Mahasiswa extends CivitasAkademika implements InfoCivitas {
    private String NIM;
    private int semester;
    private Fakultas fakultas;
    private static int counterMahasiswa = 0;

    public Mahasiswa(String nama, String email, String NIM, int semester, Fakultas fakultas){
        super(nama, email);
        this.NIM = NIM;
        this.semester = semester;
        this.fakultas = fakultas;
        counterMahasiswa++;
    }

    public String getNIM(){
        return NIM;
    }

    public int getSemester(){
        return semester;
    }

    public void setNIM(String NIM){
        this.NIM = NIM;
    }

    public void setSemester(int semester){
        this.semester = semester;
    }
    
    public static int getcounterMahasiswa(){
        return counterMahasiswa;
    }

    public double hitungUKT(){
        return fakultas.getTarifUKT() * Math.pow(0.95, semester - 1);
    }

    @Override
    public void tampilkanInformasi(){
        System.out.println("=============INFORMASI MAHASISWA============");
        System.out.println("Mahasiswa: " + nama);
        System.out.println("Email: " + email);
        System.out.println("NIM: " + NIM );
        System.out.println("Semester: " + semester);
        System.out.println("Fakultas: " + fakultas.getNama());
        System.out.println("UKT: " + hitungUKT());
    }
}