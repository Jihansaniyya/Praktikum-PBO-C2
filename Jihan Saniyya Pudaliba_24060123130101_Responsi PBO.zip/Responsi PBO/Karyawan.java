public abstract class Karyawan extends CivitasAkademika {
    protected String NIP;
    protected int masakerja;
    protected static int counterKaryawan = 0;

    public Karyawan(String nama, String email, String NIP, int masakerja){
        super(nama, email);
        this.NIP = NIP;
        this.masakerja = masakerja;
        counterKaryawan++;
    }

    public String getNIP(){
        return NIP;
    }

    public int getMasaKerja(){
        return masakerja;
    }

    public void setNIP(String NIP){
        this.NIP = NIP;
    }

    public void setMasaKerja(int masakerja){
        this.masakerja = masakerja;
    }

    public static int getCounterKaryawan(){
        return counterKaryawan;
    }

    public abstract double hitungGaji();


}
