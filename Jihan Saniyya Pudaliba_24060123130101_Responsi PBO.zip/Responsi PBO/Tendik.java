public class Tendik extends Karyawan implements InfoCivitas {
    private static int counterTendik = 0;

    public Tendik(String nama, String email, String NIP, int masakerja) {
        super(nama, email, NIP, masakerja);
        counterTendik++;
    }

    public double hitungGaji(){
        return 4000000 + (masakerja * 0.01 * 4000000);
    }

    public static int getCounterTendik(){
        return counterTendik;
    }

    @Override
    public void tampilkanInformasi(){
        System.out.println("===============INFORMASI TENDIK===================");
        System.out.println("NIP: " + NIP);
        System.out.println("Nama: " + nama);
        System.out.println("Email: " + email);
        System.out.println("Masa Kerja: " + masakerja);
        System.out.println("Gaji: " + hitungGaji());
    }
}
