public class Main {
    public static void main(String[] args) {
        Fakultas fakultasFSM = new Fakultas("FSM", 5500000, 4000000);
        Mahasiswa mhs1 = new Mahasiswa("JEJU", "jejubi@gmail.com", "40150", 6, fakultasFSM);
        Mahasiswa mhs2 = new Mahasiswa("Jihan", "jihanul@gmail.com", "30101", 4, fakultasFSM);
        Dosen dosen1 = new Dosen("Aris", "aris1@gmail.com", "112233", 15, fakultasFSM);
        Dosen dosen2 = new Dosen("Aisyah", "aisssy@gmail.com", "823458", 4, fakultasFSM);
        Tendik tendik1 = new Tendik("Beni", "beniuye@gmail.com", "986745", 10);
        
        System.out.println("=======================TAMPILAN INFORMASI=======================");
        mhs1.tampilkanInformasi();
        System.out.println();
        mhs2.tampilkanInformasi();
        System.out.println();
        dosen1.tampilkanInformasi();
        System.out.println();
        dosen2.tampilkanInformasi();
        System.out.println();
        tendik1.tampilkanInformasi();
        System.out.println();

        System.out.println("=======================JUMLAH INSTANCE=======================");
        System.out.println("Total Mahasiswa: " + Mahasiswa.getcounterMahasiswa());
        System.out.println("Total Dosen: " + Dosen.getCounterDosen());
        System.out.println("Total Tendik: " + Tendik.getCounterTendik());
        System.out.println("Total Karyawan: " + Karyawan.getCounterKaryawan());
    }
}
