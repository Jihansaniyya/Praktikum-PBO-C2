public interface InfoCivitas {
    void tampilkanInformasi();
}
